package com.sxjs.jd.composition.main.homefragment;

/**
 * @author：admin on 2017/4/6 16:49.
 */

interface PositionChangedListener {
    void currentPosition(int position);
}
