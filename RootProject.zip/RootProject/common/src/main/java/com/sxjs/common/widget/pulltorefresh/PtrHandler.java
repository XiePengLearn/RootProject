package com.sxjs.common.widget.pulltorefresh;

public interface PtrHandler {

    /**
     * When refresh begin
     *
     * @param frame
     */
    public void onRefreshBegin(final PtrFrameLayout frame);
}